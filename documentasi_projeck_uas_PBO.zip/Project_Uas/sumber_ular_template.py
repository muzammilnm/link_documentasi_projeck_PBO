"""
 Simple snake example.
 
 Sample Python/Pygame Programs
 Simpson College Computer Science
 http://programarcadegames.com/
 http://simpson.edu/computer-science/
 
"""
 
import pygame
 
# --- Globals ---
# Warna
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
 
# Atur lebar dan tinggi masing-masing segmen ular.
segment_width = 15
segment_height = 15
# Margin antara setiap segmen.
segment_margin = 5
 
# Setel kecepatan awal.
x_change = segment_width + segment_margin
y_change = 0
 
 
class Segment(pygame.sprite.Sprite):
    """ Class to represent one segment of the snake. """
    # -- Methods
    # Constructor function
    def __init__(self, x, y):
        # panggil constructor parent / inherit. 
        super().__init__()
 
        # mengatur tinggi dan lebar.
        self.image = pygame.Surface([segment_width, segment_height])
        self.image.fill(WHITE)
 
        # Buat sudut kiri-kiri kami lokasi yang dilewati.
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
 
# Panggil fungsi ini sehingga pustaka Pygame dapat melakukan inisialisasi sendiri
pygame.init()
 
# membuat tampilan screen dengan ukuran ( 800, 600 ).
screen = pygame.display.set_mode([800, 600])
 
# Memberi nama pada tittle.
pygame.display.set_caption('Snake Example')
 
allspriteslist = pygame.sprite.Group()
 
# Buat ular awal
snake_segments = []
for i in range(15):
    x = 0 - (segment_width + segment_margin) * i #kemunculan ular vertical ( max 785 )
    y = 300 #kemunculan ular horizontal ( max 584 )
    segment = Segment(x, y)
    snake_segments.append(segment)
    allspriteslist.add(segment)
 

clock = pygame.time.Clock()
done = False
 
while not done:
 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
 
        # Atur kecepatan berdasarkan tombol yang ditekan
        # Kami ingin kecepatan menjadi cukup sehingga kami bergerak penuh.
        # segmen, ditambah margin.
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                x_change = (segment_width + segment_margin) * -1
                y_change = 0
            if event.key == pygame.K_RIGHT:
                x_change = (segment_width + segment_margin)
                y_change = 0
            if event.key == pygame.K_UP:
                x_change = 0
                y_change = (segment_height + segment_margin) * -1
            if event.key == pygame.K_DOWN:
                x_change = 0
                y_change = (segment_height + segment_margin)
 
    # Singkirkan bagian terakhir dari ular
    # .pop () perintah menghapus item terakhir dalam daftar
    old_segment = snake_segments.pop()
    allspriteslist.remove(old_segment)
 
    # Cari tahu di mana segmen baru akan berada
    if x <= 785 and y <= 585:
        if x >= 0:
            x = snake_segments[0].rect.x + x_change
            print(x)
            y = snake_segments[0].rect.y + y_change
            print(y)
            segment = Segment(x, y)
        else:
            x = snake_segments[0].rect.x + 800
            print(x)
            y = snake_segments[0].rect.y + y_change
            print(y)
            segment = Segment(x, y)
    else:
        if x >= 785:
            x=snake_segments[0].rect.x-800
            y=snake_segments[0].rect.y+0
            segment = Segment(x, y)
    # Masukkan segmen baru ke dalam daftar
    snake_segments.insert(0, segment)
    allspriteslist.add(segment)
    
        
 
    # -- Gambar semuanya
    # Bersihkan layar
    screen.fill(BLACK)
 
    allspriteslist.draw(screen)
 
    # Layar Flip
    pygame.display.flip()
 
    # Pause
    clock.tick(5)
 
pygame.quit()
