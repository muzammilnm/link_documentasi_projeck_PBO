import kivy
kivy.require('1.2.0')
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.properties import ObjectProperty, NumericProperty, ListProperty
import math

class Kalkulator(Widget):
    def __init__(self):
        self.lastop = ""
        self.memorynum = 0.0
        self.operation = False
        self.appOn = False
        display = ObjectProperty(None)
        super().__init__()

    def actionTombol(self, klik):
        if klik == "ON":
            self.appOn = True
            
        if klik == "OFF":
            kosong = ""
            self.appOn = False
            self.display.text = kosong

        if klik == "Exit":
                exit()
            
        if self.appOn == True:
            if klik in "0123456789.":
                if self.lastop == "":
                    self.lastop = ""
                self.displayInputan(klik)
                
            elif klik in "+-:x%^//" and self.lastop != "=":
                if self.lastop != "":
                    self.perhitungan(klik)
                else:
                    self.memorynum = float(self.display.text)
                self.lastop = klik
                self.operation = True

            elif klik in "Cc":
                self.display.text = ""
                self.memorynum = 0.0
                self.lastop = ""

            elif klik == "=" and self.lastop != "=":
                self.perhitungan(klik)
                self.memorynum = 0.0
                self.lastpp = "="
                self.operation = True

            elif klik == "1/2" and self.lastop != "=":
                self.display.text = str(float(self.display.text)/2)

            elif klik == "+/-" and self.lastop != "=":
                men = int(self.display.text)
                if self.display.text[0] != "-":
                    men = men - (men*2)
                else:
                    men = men * -1
                self.display.text = str(men)
            elif klik == "<" and self.lastop != "=":
                self.display.text = self.display.text[:-1]

            elif klik == ">" and self.lastop != "=":
                self.display.text = self.display.text[1:]

            elif klik == "Akar" and self.lastop != "=":
                akar = int(self.display.text)
                akardari = math.sqrt(akar)
                self.display.text = str(akardari)

    def perhitungan(self, klik):
        if self.lastop == "+":
            self.memorynum  += float(self.display.text)
            print("+")
        elif self.lastop == "-":
            self.memorynum -= float(self.display.text)
        elif self.lastop == ":":
            self.memorynum /= float(self.display.text)
        elif self.lastop == "x":
            self.memorynum *= float(self.display.text)
        elif self.lastop == "%":
            self.memorynum %= float(self.display.text)
        elif self.lastop == "^":
            self.memorynum **= float(seelf.display.text)
        elif self.lastop == "//":
            self.memorynum //= float(self.display.text)
        self.display.text = str(self.memorynum)
            

    def displayInputan(self, klik):
        if klik == "." and "." in self.display.text:
            return
        if self.operation:
            self.display.text = klik
            self.operation = False
        else:
            self.display.text += klik
    
    

class MainApp(App):
    def build(self):
        self.Calc = Kalkulator()
        return self.Calc

if __name__ == "__main__":
    app = MainApp()
    app.run()
