import pygame
import time
import random

pygame.init()
white = ( 255, 255, 255 )
black = ( 20, 20, 20 )
red = ( 255, 0, 0 )
blue = ( 0, 0, 255 )
green = ( 0, 0, 0 )

# menginisilisasi variable font untuk megambil method font pada library pygame
font = pygame.font.SysFont(None, 25)

class screen:

    __level = 1
    __score = 0
    __poin = 0
    __win = 25
    def __init__(self, height, width):
        self.__height = height
        self.__width = width
        
        self.gameDisplay = pygame.display.set_mode(( self.__height, self.__width ))
        pygame.display.set_caption("Tugas_PBO")

    def scoreGame(self, messegeScore, warna):
        score_text = font.render(messegeScore, True, warna)
        self.gameDisplay.blit(score_text, [0, 0])

    def messege_to_screen(self, messege, color):
        screen_text = font.render(messege, True, color)
        self.gameDisplay.blit(screen_text, [400, 300])

    def messege_level_screen(self, msglevel, color):
        screen_text = font.render(msglevel, True, color)
        self.gameDisplay.blit(screen_text, [700, 0])
        
class position:
    rand_target_x = round(random.randrange(0, 800-10)/10.0)*10.0
    rand_target_y = round(random.randrange(0, 600-10)/10.0)*10.0
    rand_target_xY = round(random.randrange(0, 800-30)/10.0)*10.0
    rand_target_yX = round(random.randrange(0, 600-30)/10.0)*10.0

    rand_target_xY1 = round(random.randrange(0, 800-40)/10.0)*10.0
    rand_target_yX1 = round(random.randrange(0, 600-40)/10.0)*10.0

    rand_target_xY2 = round(random.randrange(0, 800-50)/10.0)*10.0
    rand_target_yX2 = round(random.randrange(0, 600-50)/10.0)*10.0

    rand_target_xY3 = round(random.randrange(0, 800-60)/10.0)*10.0
    rand_target_yX3 = round(random.randrange(0, 600-60)/10.0)*10.0

    rand_target_xY4 = round(random.randrange(0, 800-70)/10.0)*10.0
    rand_target_yX4 = round(random.randrange(0, 600-70)/10.0)*10.0

    rand_target_xY5 = round(random.randrange(0, 800-80)/10.0)*10.0
    rand_target_yX5 = round(random.randrange(0, 600-80)/10.0)*10.0

    rand_target_xY6 = round(random.randrange(0, 800-90)/10.0)*10.0
    rand_target_yX6 = round(random.randrange(0, 600-90)/10.0)*10.0

    rand_target_xY7 = round(random.randrange(0, 800-100)/10.0)*10.0
    rand_target_yX7 = round(random.randrange(0, 600-100)/10.0)*10.0

    rand_target_xY8 = round(random.randrange(0, 800-110)/10.0)*10.0
    rand_target_yX8 = round(random.randrange(0, 600-110)/10.0)*10.0
    
    def __init__(self, x, y):
        # mengatur posisi awal dari snake
        self.__lead_x = x
        self.__lead_y = y

        # mencari tahu posisi snake selanjutnya
        self.lead_x_change = 0
        self.lead_y_change = 0
        

class snack(position):
    lenSnack = 15
    lisSnack = []
    geometri = []
    def __init__(self,x, y, height, width):
        self.__lead_x = x
        self.__lead_y = y
        self.__height = height
        self.__width = width
        super().__init__(self.__lead_x, self.__lead_y)

    def createSnack(self, color1):
        for i in range(self.lenSnack):
            pygame.draw.rect(screen.gameDisplay, color1, [self.__lead_x, self.__lead_y, self.__height, self.__width])

class Bait(position):
    def __init__(self,x, y, height, width):
        self.__lead_x = x
        self.__lead_y = y
        self.__height = height
        self.__width = width
        super().__init__(self.__lead_x, self.__lead_y)

    def createBait(self, color2):
        pygame.draw.rect(screen.gameDisplay, color2, [self.rand_target_x, self.rand_target_y, self.__height, self.__width])
            
            

class Poison(position):
    def __init__(self, x, y, height, width):
        self.__lead_x = x
        self.__lead_y = y
        self.__height = height
        self.__width = width
        super().__init__(self.__lead_x, self.__lead_y)

    def createPoison(self, color3, x, y):
        pygame.draw.rect(screen.gameDisplay, color3, [x, y, self.__height, self.__width])


screen = screen(800, 600)
snack = snack(300, 300, 10, 10)
bait = Bait(300, 300, 10, 10)
poison1 = Poison(300, 300, 10, 10)
poison2 = Poison(300, 300, 10, 10)
poison3 = Poison(300, 300, 10, 10)
poison4 = Poison(300, 300, 10, 10)
poison5 = Poison(300, 300, 10, 10)
poison6 = Poison(300, 300, 10, 10)
poison7 = Poison(300, 300, 10, 10)
poison8 = Poison(300, 300, 10, 10)
poison9 = Poison(300, 300, 10, 10)

class keyboard:
    def left(self):
        snack.lead_x_change = -10
        snack.lead_y_change = 0

    def right(self):
        snack.lead_x_change = 10
        snack.lead_y_change = 0

    def up(self):
        snack.lead_y_change = -10
        snack.lead_x_change = 0

    def down(self):
        snack.lead_y_change = 10
        snack.lead_x_change = 0

keyboard = keyboard()

class gameLoop:
    def __init__(self):
        self.FPS = 10
    
        #menginisialisasi variable 'clock' untuk mengatur kecepatan snake
        self.clock = pygame.time.Clock()

        # menginisialisasi variable 'gameExit' sebagai pemberhentian dari game
        self.gameExit = False
        
    def game(self):
        while not self.gameExit:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.gameExit = True
                    
                # pergerakan snake sesuai aksi yang dilakukan
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        keyboard.left()
                    if event.key == pygame.K_RIGHT:
                        keyboard.right()
                    if event.key == pygame.K_UP:
                        keyboard.up()
                    if event.key == pygame.K_DOWN:
                        keyboard.down()

            # game berhenti ketika snake keluar area
            if snack._snack__lead_x > 800 or snack._snack__lead_x < 0 or snack._snack__lead_y > 600 or snack._snack__lead_y < 0:
                self.gameExit = True

            # perubahan posisi pertama pada snack
            snack._snack__lead_x += snack.lead_x_change
            snack._snack__lead_y += snack.lead_y_change


            # memberi warna 'white' pada tampilan screen
            screen.gameDisplay.fill(black)

            lenMusuh = []
            posisiMusuh = []
            totalMusuh = 1
            
            # membuat objek berbentuk 'rect' dan memberi warna 'black'
            snack.createSnack(white)
            bait.createBait(blue)
            poison1.createPoison(red, position.rand_target_xY, position.rand_target_yX)
            poison2.createPoison(red, position.rand_target_xY1, position.rand_target_yX1)
            poison3.createPoison(red, position.rand_target_xY2, position.rand_target_yX2)
            poison4.createPoison(red, position.rand_target_xY3, position.rand_target_yX3)
            poison5.createPoison(red, position.rand_target_xY4, position.rand_target_yX4)
            poison6.createPoison(red, position.rand_target_xY5, position.rand_target_yX5)
            poison7.createPoison(red, position.rand_target_xY6, position.rand_target_yX6)
            poison8.createPoison(red, position.rand_target_xY7, position.rand_target_yX7)
            poison9.createPoison(red, position.rand_target_xY8, position.rand_target_yX8)
            
            screen.scoreGame("Score : %d"%screen._screen__score, white)
            screen.messege_level_screen("Level : %d"%screen._screen__level, white)
            # melakukan update disetiap perubahan yang dilakukan.
            
            if snack._snack__lead_x == bait.rand_target_x and snack._snack__lead_y == bait.rand_target_y:
                screen._screen__score += 5
                bait.rand_target_x = round(random.randrange(0, 800-20)/10.0)*10.0
                bait.rand_target_y = round(random.randrange(0, 600-20)/10.0)*10.0

            if snack._snack__lead_x == poison1.rand_target_xY and snack._snack__lead_y == poison1.rand_target_yX:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison2.rand_target_xY1 and snack._snack__lead_y == poison2.rand_target_yX1:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY1 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX1  = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison3.rand_target_xY2 and snack._snack__lead_y == poison3.rand_target_yX2:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY2 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX2 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison4.rand_target_xY3 and snack._snack__lead_y == poison4.rand_target_yX3:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY3 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX3 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison5.rand_target_xY4 and snack._snack__lead_y == poison5.rand_target_yX4:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY4 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX4 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison6.rand_target_xY5 and snack._snack__lead_y == poison6.rand_target_yX5:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY5 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX5 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison7.rand_target_xY6 and snack._snack__lead_y == poison7.rand_target_yX6:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY6 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX6 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison8.rand_target_xY7 and snack._snack__lead_y == poison8.rand_target_yX7:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY7 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX7 = round(random.randrange(0, 600-30)/10.0)*10.0

            if snack._snack__lead_x == poison9.rand_target_xY8 and snack._snack__lead_y == poison9.rand_target_yX8:
                screen.gameDisplay.fill(green)
                screen._screen__score -= 5
                position.rand_target_xY8 = round(random.randrange(0, 800-30)/10.0)*10.0
                position.rand_target_yX8 = round(random.randrange(0, 600-30)/10.0)*10.0



            if screen._screen__score - screen._screen__poin == screen._screen__win:
                self.FPS += 5
                screen._screen__level += 1
                screen._screen__poin += screen._screen__win
                
            
            if screen._screen__score < 0:
                self.gameExit = True

            self.clock.tick(self.FPS)
            pygame.display.update()
        screen.messege_to_screen("Game Over ! , Score : %d"%screen._screen__score, white)
        # melakukan update disetiap perubahan yang dilakukan.
        pygame.display.update()
        # melakukan jeda selama 1 detik sebelum keluar dari game
        time.sleep(2)
        pygame.quit()
gameLoop = gameLoop()
gameLoop.game()
